
def cal_price():
    print("Total price")


def tax():
    pass


if __name__ == "__main__":
    print("sales modules")
else:
    print(__name__)
