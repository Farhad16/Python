print("Shopping started")
