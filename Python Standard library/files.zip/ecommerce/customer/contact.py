def customer_contact():
    pass
